import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-consumer-profile-create',
  templateUrl: './consumer-profile-create.component.html',
  styleUrls: ['./consumer-profile-create.component.css']
})
export class ConsumerProfileCreateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
